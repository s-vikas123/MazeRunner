# Files for 7785 Lab 6

***For Lab 6, you will be developing the software to make the Turtlebot follow signs on the walls of a maze to get to the goal. This Gazebo environment should help you with your code development for this final lab. The files in this repository are used to create the simulated environment you can leverage to develop and test your solution. If you wreck your Turtlebot3 files or the Gazebo files associated with them, repull the `turtlebot3` directory if you pulled the github repository directly or reinstall the debian package to fix the error.***

*** :warning: This should all be done on your computer as it is only meant for the simulator! :warning: ***

To make this environment usable for the final lab, modify the Turtlebot3 simulation files if you haven't already in Lab 5 to include a camera. Please follow the direction in this Github repository: [https://github.gatech.edu/swilson64/turtlebot3_sim_update](https://github.gatech.edu/swilson64/turtlebot3_sim_update)

:warning: All of the Lab6 gazebo files are different from the Lab 5 files. So while the file names may be similar, the files for Lab 6 are different and you will need to replace the old ones with these files. :warning:

## Adding the necessary files to the Turtlebot3 Gazebo Simulation Repository

1. Add the maze files to the Turtlebot3 Gazebo files. Copy the `7785_maze` directory in this git repository into the directory,  
        <p style="text-align: center;"> `<YOUR TURTLEBOT3 ROS WS>/src/turtlebot3_simulations/turtlebot3_gazebo/models/` </p>

> :warning: Note that this directory path may change depending on which ROS2 workspace you used to clone the the Turtlebot packages. :warning: 

2. Move or copy the `7785_maze.launch.py` file in this git repository into the directory,  
        <p style="text-align: center;"> `<YOUR TURTLEBOT3 ROS WS>/src/turtlebot3_simulations/turtlebot3_gazebo/launch/` </p>

> :warning: Note that this directory path may change depending on which ROS2 workspace you used to clone the the Turtlebot packages. :warning: 

3. Move or copy the `7785_maze.world` file in this git repository into the directory,  
        <p style="text-align: center;"> `<YOUR TURTLEBOT3 ROS WS>/src/turtlebot3_simulations/turtlebot3_gazebo/worlds/` </p>

> :warning: Note that this directory path may change depending on which ROS2 workspace you used to clone the the Turtlebot packages. :warning: 

4. Move or copy the `models` folder in this git repository into the `.gazebo` directory in your /home/<user>/ directory, 
	<p style="text-align: center;"> `~/.gazebo/` </p>
> Note: the `/.gazebo` folder is a *hidden* folder. It is most likely in your `/home/<user>/` folder. Using Nautilus, you can use `cntrl-h` to view hidden files or in the terminal you can use ls -a. You can also unhide hidden files in the Files window by using the shortcut `Crtl+H`.
	
5. Return back to the `turtlebot3_ws` directory and run `colcon build`.
6. Make sure to run `source install/setup.bash` for changes to reflect.
7. To use the Gazebo environment, run:
`ros2 launch turtlebot3_gazebo 7785_maze.launch.py `

## Notes on Gazebo Simulation:
Unlike the real Turtlebot3 robot, **Gazebo does NOT use the `CompressedImage` topic**. Instead, it uses the `Image` topic. Therefore, when subscribing to the camera node, be sure to use the `/camera/image_raw` topic and NOT the `/camera/image/compressed`. When you deploy your code on the real robot, you will need to change this back. This also affects to the `CvBridge`. You will need to use the `imgmsg_to_cv2()` method instead of `compressed_imgmsg_to_cv2`.

**Sample Video Subscriber:**
```
# Gazebo Video Subscriber
self._video_subscriber = self.create_subscription(
        Image,
        '/camera/image_raw',
        self._image_callback,
        1)
self._video_subscriber # Prevents unused variable warning.
```

**Sample image_callback:**
```
 def _image_callback(self, CompressedImage):	
        self._imgBGR = CvBridge().imgmsg_to_cv2(Image, "bgr8")
```

:warning: IMPORTANT BUG FIXES BELOW :warning:

If you get the error message that process has died on launch of gazebo and somewhere in the error message you see `px!=0` the solution is as follows:
1. In your `~/.bashrc` file, add the following line: `source /usr/share/gazebo/setup.bash`
2. Source the bashrc in every open terminal: `source ~/.bashrc`
3. Success, hopefully.


If the robot spawns in outside of the maze, the issue may be that navigation2 was executed before the gazebo environment was launched. Make sure to launch the gazebo environment first and foremost before any other ros2 code to avoid any such undesired behavior.

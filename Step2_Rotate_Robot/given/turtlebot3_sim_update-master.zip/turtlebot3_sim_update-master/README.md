
# Adding a Camera to the Turtlebot3 Gazebo Model

***To enable the Turtlebot3 Gazebo model to simulate a camera, a few files must be changed and added. If you wreck your Turtlebot3 files or the Gazebo files associated with them, repull the `turtlebot3` directory if you pulled the github repository directly or reinstall the debian package to fix the error.***

***This should all be done on your computer as it is only meant for the simulator!***

## Altering the Turtlebot3 Burger Gazebo Model

First let's add some STL files to make the simulation model of the Turtlebot3 have more detail. Copy all the STL files from the 'gazeboModel' directory in this git repository into the directory,  
        <p style="text-align: center;"> `<YOUR TURTLEBOT3 ROS WS>/src/turtlebot3_simulations/turtlebot3_gazebo/models/turtlebot3_common/meshes/` </p>

> :warning: Note that this directory path may change depending on where you created your ROS2 workspace for the Turtlebot. :warning: 

Copy the 'model.sdf' file from the 'gazeboModel' directory in this git repository into the directory,  
        <p style="text-align: center;"> `<YOUR TURTLEBOT3 ROS WS>/src/turtlebot3_simulations/turtlebot3_gazebo/models/turtlebot3_burger/` </p>

> :warning: Note that this directory path may change depending on where you created your ROS2 workspace for the Turtlebot. :warning: 

Finally, copy 'turtlebot3_burger.urdf' from the 'gazeboModel' directory in this git repository into the directory,
        <p style="text-align: center;"> `<YOUR TURTLEBOT3 ROS WS>/src/turtlebot3_simulations/turtlebot3_gazebo/urdf/` </p>

> :warning: Note that this directory path may change depending on where you created your ROS2 workspace for the Turtlebot. :warning: 

## Information About the Modified Code

The file 'model.sdf' contains the simulated camera model parameters within the file you may want to edit.
 
 **Camera FPS:** `<update_rate>30.0</update_rate>`  
 **Resolution and Format:**  
`<image>`  
`<width>1280</width>`  
`<height>960</height>`  
`<format>R8G8B8</format>`  
`</image>`

Additionally, the node and topic name created by the simulated camera are.

 **Node name:** `turtlebot3_simulated_camera`  
 **Raw Image Topic name:** `/simulated_camera/image_raw`
 **Compressed Image Topic name:** `/simulated_camera/image_raw/compressed` 

You should now be all set to run the simulation environment containing a turtlebot with a simulated rpi_camera.

## Checking the Camera

For simulation,

run `ros2 launch turtlebot3_gazebo turtlebot3_world.launch.py`
> Gazebo should launch an environment that looks like a turtle with the turtlebot inside.

You're all set! You can run teleop to move the robot around and access the camera view using
'ros2 run rqt_image_view rqt_image_view'
